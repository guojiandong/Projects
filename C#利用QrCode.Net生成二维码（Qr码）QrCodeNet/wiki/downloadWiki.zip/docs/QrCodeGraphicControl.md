# QrCodeGraphicControl
This page provides a guide for use QrCodeGraphicControl. (After **check-in 15097**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.Forms

### Syntax
{code:c#}
public class QrCodeGraphicControl : Control
{code:c#}
### Remarks
QrCodeGraphicControl is WinForm control.

QrCodeGraphicControl override Control's OnPaint event to display QrCode. Each time OnPaint event raise, it will read whole Bitmatrix and paint it on Control. 

Very straight forward implementation. Memory cost is low. It will be performance hit if it encounter large version of QrCode. Also if half of control covered by other object, it will still perform full QrCode paint action. (Version of QrCode please check QrCode Info here)

### Constructors
||Name||Description||
|QrCodeGraphicControl|Initializes a new instance of QrCodeGraphicControl class.|

### Methods
||Name||Description||
|Lock|Lock class, changes to Text or ErrorCorrectLevel properties won't update QrCode|
|[Unlock](http://goo.gl/3OYYE)|Unlock class and re-encode, then repaint control if is not freezed|
|Freeze|Freeze class, changes to any visual properties won't repaint QrCode|
|UnFreeze|Unfreeze class and repaint QrCode|
|GetQrMatrix|Return clone of BitMatrix for QrCode. Bitmatrix value is null if text is empty or text is too large|
|OnDarkBrushChanged|Raises when DarkBrush's value changed|
|OnLightBrushChanged|Raises when LightBrush's value changed|
|OnQuietZoneModuleChanged|Raises when QuietZoneModule value changed|
|OnErrorCorrectLevelChanged|Raises when ErrorCorrectLevel value changed|
|OnQrMatrixChanged|Raises after re-encode QrMatrix|

### Properties
||Name||Description||
|DarkBrush|Brush for dark modules|
|LightBrush|Brush for light modules|
|QuietZoneModule|Number of modules for width of Quiet Zone|
|ErrorCorrectLevel|Error correction level for QrCode encode|
|Text|Input string for QrCode|
|IsFreezed|Boolean state if class is freezed|
|IsLocked|Boolean state if class is locked|

### Events
||Name||Description||
|DarkBrushChanged|Occurs when DarkBrush changes|
|LightBrushChanged|Occurs when LightBrush changes|
|QuietZoneModuleChanged|Occurs when QuietZoneModule changes|
|ErrorCorrectLevelChanged|Occurs when ErrorCorrectLevel changes|
|QrMatrixChanged|Occurs when re-encode, and BitMatrix changes|

### Example
{code:c#}
using Gma.QrCodeNet.Encoding.Windows.Forms;
using Gma.QrCodeNet.Encoding; //Import this only if you want to extract bitmatrix.
{code:c#}

{code:c#}
QrCodeGraphicControl qrControl = new QrCodeGraphicControl();

//control update text then encode and repaint.
qrControl.Text = "QrCode.Net";

BitMatrix qrMatrix = qrControl.GetQrMatrix(); //Qr bit matrix for input string "QrCode.Net".

qrControl.Lock();  //Lock class.
qrControl.ErrorCorrectLevel = ErrorCorrectionLevel.M;  //It won't encode and repaint.
qrControl.Text = "next test";
qrMatrix = qrControl.GetQrMatrix(); //Qr bit matrix for input string "QrCode.Net".
qrControl.Unlock(); //Unlock class, re-encode and repaint. 

qrMatrix = qrControl.GetQrMatrix(); //Qr bit matrix for input string "next test".

qrControl.Freeze() //Freeze class.
qrControl.DarkBrush = Brushes.Red; //It won't repaint QrCode.
qrControl.Text = "freeze test"; //Control will re-encode, but won't repaint right away. Unless windows re-renderer this control.
qrMatrix = qrControl.GetQrMatrix();  //QrCode matrix for string "Freeze test"
qrControl.UnFreeze(); //Repaint control. 

qrControl.Lock();
qrControl.Freeze();
qrControl.LightBrush = Brushes.Yellow;  //It won't repaint QrCode.
qrControl.Text = "Lock and Freeze test";  //Control won't re-encode.
qrMatrix = qrControl.GetQrMatrix();  //QrCode matrix is still for string "Freeze test"
qrControl.Unlock();    //Unlock class, re-encode QrCode but won't repaint QrCode
qrControl.Unfreeze();  //UnFreeze class, repaint QrCode.

//If lock and freeze together. Always Unlock before Unfreeze. Else it will repaint QrCode twice. 
{code:c#}