# QrCode
This page provide information about QrCode and data structure that present it.


![QrCode](QrCode_QrCodeV7.png)
# Black: Position mark
# Purple: Format information and its error correction code
# Red: Version information and its error correction code.
# Gray: Data and its error correction code.


![](QrCode_Qr EC.png)

### Version
Normal QrCode has version from 1 to 40. QrMatrix width is equal to 17 plus 4 times version number.
Ex: Version 7 width = 17 + 4 * 7 which is 45.

### Module
QrMatrix is present as boolean matrix. Each boolean value we draw it as a fixed size square, which we call it module. Boolean true also we can call it bit 1, we draw it as dark colour, which we call it dark module. Same as to light module we use light colour. 

### Module's colour
When we come into decide which colour we are going to use for QrCode, first thing come into our mind is black and white set up. But decoder doesn't really care which colour has been used, even you change Dark module to white and Light module to black. Most properly coded decoder should be able to decode properly. Thus Dark module does not have to be absolutely dark colour. It can be any colour as long as it's different compare to Light module.  

### Quiet Zone
Quiet Zone is blank area outside of QrCode matrix. Width for number of module at each side should be four if according to ISO/IEC. But two is normally acceptable for decoder. Quiet Zone should be draw by light colour. 

### Position mark
Position mark is the mark to indicate the location of code and direction. It also include alignment mark.

### Format information
Format information is a block to which mask QrCode used, and which level of error correction. 

### Version information
This block will only exist at version 7 or after. It will not be present at low version QrCode. It will tell decoder current QrCode's version.

### Data
Bits that contain transformed user input data and error correction to that data. It also have information about char encoder it used. 

### Mask
To make QrCode's dark and light module spread balanced, we use data masking at gray area, where data and its error correction bits are. 

### Error Correction
QrCode uses ReedSolomon for error correction block. Reed-Solomon codes are suitable as multiple-burst bit error correcting codes. More detail you could find out [here](http://en.wikipedia.org/wiki/Reed%E2%80%93Solomon_error_correction).

### Error Correction Level
Error correction level indicate the level of protection for input data. The high level we use, the more damage QrCode could take before become unreadable. Drawback is it will need more error correction data to store inside QrCode, sometime result as few versions bigger than using low level error correction. 

### Difference between different ISO
There are several ISO for QrCode. For example 18004:2000, 18004:2006, 18284:2000. The difference between are mainly relate to the location where they use at. 18004:2000, 18004:2006 are both international standard, where 18284:2000 and other ISO are for different country. Korean, China, Thai all have their own ISO. 

Major difference inside QrCode for different ISO is eight bit encode for string char. There are so many different encoder for eight bit encode under ECI set. For example, iso-8859-1 is standard European char table, utf8 for Unicode,  shift-jis for japanese. They all use same ECI set, but default char table are different. Default char table doesn't have to indicate ECI header inside QrCode. 

18004:2000 default char table is shift-jis
18004:2006 default char table is iso-8859-1
18284:2000 default char table is ASCII

There is also one minor difference between 18004:2000 and 18004:2006. Which is data mask's penalty calculation, but it is not noticeable difference. Decoder won't know which one belong to 2000 or 2006. So the major viable difference is just default char table. 

### ECI
ECI is extended channel interpretation. People who interest at it could check out on web. 

### Data Structure that QrCode.Net uses. 
BitMatrix: Bitmatrix use to contain QrCode matrix. It's width x width square boolean matrix. Width calculation could see above, normally you don't have to worry about it, just use property width from Bitmatrix class. Bitmatrix does not include quiet zone.

QuietZoneModules: Enum for indicate the width size of quiet zone. It contains: zero, two, four. Zero is for people want to draw QrCode at place where background is same as QrCode's light module colour. So QrCode is already guarantee surround by suitable light colour zone.  