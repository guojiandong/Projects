# DrawingBrushRenderer
This page provides a guide for use DrawingBrushRenderer. (After **check-in 13336**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.Render

### Syntax
{code:c#}
public class DrawingBrushRenderer
{code:c#}

### Remarks
DrawingBrushRenderer is a renderer that uses geometry to create DrawingBrush or Geometry groups. It also able to write image to stream.

Stream geometry has been used within this class for better performance. 

It can write QrCode image to stream. It supports any format under BitmapEncoder, also able to give BitmapSource and let user to encode image on their own. This brings more detailed encoding. 

### Constructors
||Name||Description||
|DrawingBrushRenderer|Initialize a new instance of DrawingBrushRenderer class|

### Methods
||Name||Description||
|DrawBrush|It will return DrawingBrush that contains all dark modules. Light modules will not be include inside brush|
|DrawGeometry|Returns StreamGeometry for dark modules.|
|WriteToBitmapSource|Create BitmapSource for given Qr matrix. It will include light modules|
|WriteToStream|Create Qr Image and put into stream|

### Properties
||Name||Description||
|DarkBrush|Brush for dark colour modules|
|LightBrush|Brush for light colour modules|
|ISize|Property for ISizecalculation|

### Example
{code:c#}
using Gma.QrCodeNet.Encoding.Windows.Render;
using Gma.QrCodeNet.Encoding;
{code:c#}

{code:c#}
QrEncoder encoder = new QrEncoder(ErrorCorrectLevel.M);
QrCode qrCode;
encoder.TryEncode("Test", out qrCode);

DrawingBrushRenderer dRenderer = new DrawingBrushRenderer(
    new FixedModuleSize(2, QuietZoneModules.Two), 
    Brushes.Black, Brushes.White);

DrawingBrush dBrush = dRenderer.DrawBrush(qrCode.Matrix);
Rectangle rect = new Rectangle();
rect.Width = 150;
rect.Height = 150;
rect.Fill = dBrush;
//QrCode should be at center of rectangle, and Uniform stretched. 
//Put rectangle on boarder and set up boarder's background will sort light modules out.
//Same as how to use stream geometry. It will be contain inside Path UIElement. 

MemoryStream ms = new MemoryStream();
dRenderer.WriteToStream(qrCode.Matrix, ImageFormatEnum.Png, ms, new Point(96, 96));
//new Point(96, 96) is for DPI X and DPI Y. You can use WriteToStream(BitMatrix, ImageFormatEnum, Stream) to construct image at default DPI 96 96. 

MemoryStream bms = new MemoryStream();
BitmapSource bSource = dRenderer.WriteToBitmapSource(qrCode.Matrix, new Point(96, 96));
PngBitmapEncoder pngEncoder = new PngBitmapEncoder();
pngEncoder.Interlace = PngInterlaceOption.On;
pngEncoder.Frames.Add(BitmapFrame.Create(bSource));
pngEncoder.Save(bms);
//This is example how to get bitmap source and use bitmap encoder to encode. Different bitmap encoder will have it's own specific option when encode image file. 
{code:c#}