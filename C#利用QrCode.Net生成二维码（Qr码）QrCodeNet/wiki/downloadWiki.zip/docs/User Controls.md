# User Controls
This page provides a guide for using QrCode.Net library's user controls.
_This wiki is mainly for User controls after check in 15096_

### Index
* [QrCodeGraphicControl WinForm](QrCodeGraphicControl)
* [QrCodeImgControl WinForm](QrCodeImgControl)
* [QrCodeGeoControl WPF](QrCodeGeoControlWPF)
* [QrCodeImgControl WPF](QrCodeImgControlWPF)


![Using user control at design mode](User Controls_UsingControlScreenshot.JPG)
Drag and drop user control at design mode. 