# GraphicsRenderer
This page provides a guide for use GraphicsRenderer. (After **check-in 13336**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.Render

### Syntax
{code:C#}
public class GraphicsRenderer
{code:C#}

### Remarks
GraphicsRenderer is renderer that uses method under System.Drawing to paint or create image. 

It uses Graphics for paint and Bitmap class for saving it to stream. Basically this is renderer to use under WinForm's OnPaint event. 

Currently, WriteToStream supports following image format:
Normal image: Bmp, Gif, Jpeg, Png, Tiff
MetaFile: Emf, Wmf. 

### Constructors
||Name||Description||
|GraphicsRenderer|Initializes a new instance of GraphicsRenderer class.|

### Methods
||Name||Description||
|Draw|Draw QrCode at given Graphics object|
|WriteToStream|Create specific QrCode image and store inside stream|

### Properties
||Name||Description||
|DarkBrush|Property for Dark Module's color|
|LightBrush|Property for Light Module's color|
|SizeCalculator|Property for interface ISizeCalculator|

### Example
{code:c#}
using Gma.QrCodeNet.Encoding.Windows.Render;
using Gma.QrCodeNet.Encoding;
{code:c#}

{code:c#}
QrEncoder encoder = new QrEncoder(ErrorCorrectLevel.M);
QrCode qrCode;
encoder.TryEncode("Test", out qrCode);

GraphicsRenderer gRenderer = new GraphicsRenderer(
    new FixedModuleSize(2, QuietZoneModules.Two), 
    Brushes.Black, Brushes.White);

MemoryStream ms = new MemoryStream();
gRenderer.WriteToStream(qrCode.Matrix, ImageFormat.Png, ms);
{code:c#}

{code:c#}
protected override void OnPaint(PaintEventArgs e)
{
    QrEncoder encoder = new QrEncoder(ErrorCorrectLevel.M);
    QrCode qrCode;
    encoder.TryEncode("Test", out qrCode);

    new GraphicsRenderer(
        new FixedCodeSize(200, QuietZoneModules.Two)).Draw(
            e.Graphics, qrCode.Matrix);
    //It will use default brush, black and white. and default position (0,0).
    base.OnPaint(e);
}
{code:c#}
