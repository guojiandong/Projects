# QrCodeGeoControl
This page provides a guide for use QrCodeGeoControl. (After **check-in 15097**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.WPF

### Syntax
{code:C#}
public class QrCodeGeoControl : Control
{code:C#}

### Remarks
QrCodeGeoControl is WPF user control. 

It is inheritance of WPF Control, It construct Geometry with StreamGeometry. Use Path's margin to represent Quiet Zone. Margin is recalculated at ArrangeOverride. 

Theme for this user control is stored under themes folder, file name Generic.xaml.

It might have performance hit once QrCode's version is too large, as at that time, vector object will be way too many. Also memory usage will be growing according to QrCode's version. (QrCode version has described [here](QrCode))

Visual effect like colour, quiet zone size will be handle very easily. Thus it won't have Freeze method compare to image control. 

### Constructors
||Name||Description||
|QrCodeGeoControl|Initialize a new instance of QrCodeGeoControl class.|

### Methods
||Name||Description||
|Lock|Lock class, changes to Text or ErrorCorrectLevel dependency property won't update QrCode|
|[Unlock](http://goo.gl/HrOKL)|Unlock class and re-encode. then update Geometry|
|OnQrMatrixChanged|Raises after re-encode QrMatrix|

### Properties
||Name||Description||
|LightBrush|Dependency property for light module colour|
|DarkBrush|Dependency property for dark module colour|
|QuietZoneModule|Dependency property for QuietZoneModules enum|
|ErrorCrrectLevel|Dependency property for ErrorCorrectionLevel enum|
|Text|Dependency property for input text string|
|QrGeometry|Dependency property for Geometry group(Read only)|

### Events
||Name||Description||
|QrMatrixChanged|Occur after QrCode re-encode|

### Example

**XAML**
{code:xml}
<QrCodeGeoControl Grid.Column="1" Grid.Row="1" HorizontalAlignment="Stretch" Margin="0" Name="qrControl" VerticalAlignment="Stretch" Text="test" LightBrush="#FF00CAEC" DarkBrush="#FF9F8100"></QrCodeGeoControl>
{code:xml}

**C#**
{code:C#}
qrControl.Text = "QrCode.Net";

BitMatrix qrMatrix = qrControl.GetQrMatrix();  //Qr bit matrix for input string "QrCode.Net"

qrControl.Lock();
qrControl.ErrorCorrectLevel = ErrorCrrectionLevel.M;  //It won't re-encode qrCode. 
qrControl.Text = "lock test";
qrMatrix = qrControl.GetQrMatrix();  //Bit matrix return from method is still for input string "QrCode.Net"
qrControl.Unlock();   //Re-encode and recreate Geometry.

qrControl.DarkBrush = Brushes.Blue;  //It will change Path's fill colour. visual change immediately. 
qrControl.LightBrush = Brushes.Yellow; //It will change boarder's background colour. Visual change immediately. 
{code:C#}