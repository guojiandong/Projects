# QrCodeImgControl
This page provides a guide for use WPF QrCodeImgControl. (After **check-in 15721**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.WPF

### Syntax
{code:C#}
public class QrCodeImgControl : Control
{code:C#}

### Remarks
QrCodeImgControl is WPF user control.

It is base on WriteableBitmap. The size of image within the control is set up by "QrCodeWidthInch" property. 1 inch = 2.54 centimetres. It will try to detect device's DPI and construct WriteableBitmap with proper pixel width. Default DPI is set up at 96. 

Image within control's size won't be constant, but it will be around QrCodeWIdthInch. Thus memory usage is a bit stable compare to Geometry control. But that will only viable once version of QrCode grow pass some point, also relate to the size of image.

WriteableBitmap can be set up with two different pixel format with IsGrayImage property. Gray8 and Pbgra32. Below are detail for both pixel format. 
Gray8
Number of int32 per row: (Rounds up)(writeablebitmap.pixelwidth / 4)
Number of row: writeablebitmap.pixelheight
Pbgra32
Number of int32 per row: writeablebitmap.pixelwidth
Number of row: writeablebitmap.pixelheight

### Constructors
||Name||Description||
|QrCodeImgControl|Initialize a new instance of QrCodeImgControl Class.|

### Methods
||Name||Description||
|Lock|Lock class, changes to Text or ErrorCorrectLevel dependency property won't re-encode QrCode.|
|[Unlock](http://goo.gl/itlQh)|Unlock class then re-encode QrCode and redraw WriteableBitmap if not freezed|
|Freeze|Freeze class, changes to brush, quiet zone or other visual dependency property won't redraw WriteableBitmap|
|UnFreeze|UnFreeze class, then redraw WriteableBitmap|
|OnQrMatrixChanged|Raises after re-encode QrMatrix|

### Properties
||Name||Description||
|LightColor|Dependency property for light module colour|
|DarkColor|Dependency property for dark module colour|
|QrCodeWidthInch|Dependency property for QrCode width in inch|
|QuietZoneModule|Dependency property for QuietZoneModules enum|
|ErrorCorrectLevel|Dependency property for ErrorCorrectionLevel enum|
|Text|Dependency property for input text string|
|IsGrayImage|Dependency property for boolean indicate WriteableBitmap's image format|
|WBitmap|Dependency property for WriteableBitmap|

### Events
||Name||Description||
|QrMatrixChanged|Occur after QrCode re-encode|

### Example
**XAML**
{code:xml}
<QrCodeImgControl Grid.Row="1" HorizontalAlignment="Stretch" Margin="0" Name="qrControl" VerticalAlignment="Stretch" Height="Auto" Width="Auto" Text="test" QuietZoneModule="Zero" IsGrayImage="True" LightColor="#FFFFCCFF" DarkColor="#FF910000" />
{code:xml}

**C#**
{code:C#}
qrControl.Text = "QrCode.Net";

BitMatrix qrMatrix = qrControl.GetQrMatrix();    //Qr Bit matrix for input string "QrCode.Net"

qrControl.Lock();
qrControl.ErrorCorrectLevel = ErrorCorrectionLevel.M;    //It won't re-encode qrCode
qrControl.Text= "lock test";
qrMatrix = qrControl.GetQrMatrix();    //Bit matrix return from method is still for input string "QrCode.Net"
qrControl.Unlock();   //Re-encode and redraw WriteableBitmap

qrMatrix = qrControl.GetQrMatrix();    //Bit matrix return from method is now "lock test"

qrControl.Freeze();
qrControl.DarkColor = Colors.Red;   //It won't redraw image. 
qrControl.Text = "Freeze test";   //Re-encode qrcode but won't redraw image
qrMatrix = qrControl.GetQrMatrix();    //Bit matrix return from method is now "Freeze test"
qrControl.UnFreeze();   //Redraw image

qrControl.Lock();
qrControl.Freeze();
qrControl.LightColor = Colors.Yellow;  //It won't redraw. 
qrControl.Text = "Lock & Freeze Test";  //It won't re-encode
qrMatrix = qrControl.GetQrMatrix();   //Bit matrix return from method is still "Freeze test"
qrControl.Unlock();    //Unlock class, re-encode but won't redraw
qrControl.UnFreeze();   //unfreeze and redraw image

//Unlock before UnFreeze. Else it will redraw image twice. 

qrMatrix = qrControl.GetQrMatrix();    //QrCode for input string "Lock & Freeze Test"
{code:C#}