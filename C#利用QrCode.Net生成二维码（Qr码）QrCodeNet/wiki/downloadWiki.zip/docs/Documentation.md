# QrCode Wiki:

### Index: (Documentation for latest source code)
* [QrCode Info](QrCode)
* [Renderer](Renderer)
* [User Controls](User-Controls)

![](Documentation_http://i3.codeplex.com/Images/v18207/avatar-small.png) [Developer Documentation for Contributors](Developer-Documentation-for-Contributors)


