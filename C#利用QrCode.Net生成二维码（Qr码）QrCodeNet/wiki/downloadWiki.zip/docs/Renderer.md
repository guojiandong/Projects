# Renderer
This page provides a guide for using QrCode.Net library's renderer. 
_This wiki is mainly for renderer after check in 15096_

### Remarks
We are trying to using different graphic method to help render QrCode. Thus there are numbers of different renderer to choose from. Use the one that suits your project. 

### Index
* [ISizeCalculation](Size)
* [GraphicsRenderer](GraphicsRenderer)
* [DrawingBrushRenderer](DrawingBrushRenderer)
* [WriteableBitmapRenderer](WriteableBitmapRenderer)
* [SVGRenderer](SVGRenderer)