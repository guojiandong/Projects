# WriteableBitmapRenderer
This page provides a guide for use WriteableBitmapRenderer. (After **check-in 13336**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.Render

### Syntax
{code:c#}
public class WriteableBitmapRenderer
{code:c#}

### Remarks
WriteableBitmapRenderer is a renderer directly dealing with WriteableBitmap's pixel pointer. It aims for fast paint. 

It currently only supports Gray8 and Pbgra32 pixel format.

DPI(Dot per inch) is heavily used inside this renderer. Default DPI is 96, 96. You should be aware of where you are going to use this bitmap and set up DPI according to it.

Offset is position for top left corner of QrCode. 

DrawDarkModule method should be viable for people want to paint QrCode at exist Bitmap and it has background already set up. It will paint dark modules at given offset position. 

### Constructors
||Name||Description||
|WriteableBitmapRenderer|Initialize a new instance of WriteableBitmapRenderer class.|

### Methods
||Name||Description||
|Draw|Draw QrCode at given writeablebitmap|
|DrawDarkModule|Draw dark modules at position offset with given WriteableBitmap.(It will include quiet zone gap. Set quiet zone to zero to remove that space.)|
|WriteToStream|Write QrCode to image inside stream|

### Properties
||Name||Description||
|DarkColor|Color for dark modules|
|LightColor|Color for light modules|
|ISize|Property for ISizecalculation|

### Example
{code:c#}
using Gma.QrCodeNet.Encoding.Windows.Render;
using Gma.QrCodeNet.Encoding;
{code:c#}

{code:c#}
QrEncoder encoder = new QrEncoder(ErrorCorrectLevel.M);
QrCode qrCode;
encoder.TryEncode("Test", out qrCode);

WriteableBitmapRenderer wRenderer = new WriteableBitmapRenderer(
    new FixedModuleSize(2, QuietZoneModules.Two), 
    Colors.Black, Colors.White);

WriteableBitmap wBitmap = new WriteableBitmap(200, 200, 96, 96, PixelFormat.Gray8, null);
wRenderer.Draw(wBitmap, qrCode.Matrix);

MemoryStream ms = new MemoryStream();
wRenderer.WriteToStream(qrCode.Matrix, ImageFormatEnum.png, ms);

//You can also use above wBitmap to encode to image file on your own. 
MemoryStream wms = new MemoryStream();
PngBitmapEncoder pngEncoder = new PngBitmapEncoder();
pngEncoder.Interlace = PngInterlaceOption.On;
pngEncoder.Frames.Add(BitmapFrame.Create(wBitmap));
pngEncoder.Save(wms);
{code:c#}