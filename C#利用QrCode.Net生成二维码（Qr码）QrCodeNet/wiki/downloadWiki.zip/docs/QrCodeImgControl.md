# QrCodeImgControl
This page provides a guide for us QrCodeImgControl. (After **Check-in 15097**)

**Namespace**: Gma.QrCodeNet.Encoding.Windows.Forms

### Syntax
{code:C#}
public class QrCodeImgControl : PictureBox
{code:C#}

### Remarks
QrCodeImgControl is **WinForm** control.

QrCodeImgControl uses GraphicsRenderer to generate image to memory stream, then extract back to PictureBox, then let PictureBox to handle all the stretch, repaint.

Performance is good, no matter which version of QrCode is on display. It's just display a well craft image file. It doesn't have to read whole BitMatrix when control needs to be repaint. Cons of this implementation is memory. It will take some memory to store the image file. Width and height of image is very close to control's size. 

### Constructors
||Name||Description||
||QrCodeImgControl|Initializes a new instance of QrCodeImgControl class.|

### Methods
||Name||Description||
|Lock|Lock class, changes to Text or ErrorCorrectLevel property won't update QrCode.|
|[Unlock](http://goo.gl/3OYYE)|Unlock class and re-encode, then recreate image file if not freezed|
|Freeze|Freeze class, changes to any visual properties won't recreate image.|
|UnFreeze|Unfreeze class and recreate the image|
|GetQrMatrix|Return clone of Bitmatrix for QrCode. Bitmatrix value is null if text is empty or text is too large.|
|OnDarkBrushChanged|Raises when DarkBrush's value changed|
|OnLightBrushChanged|Raises when LightBrush's value changed|
|OnQuietZoneModuleChanged|Raises when QuietZoneModule value changed|
|OnErrorCorrectLevelChanged|Raises when ErrorCorrectLevel value changed|
|OnQrMatrixChanged|Raises after re-encode QrMatrix|

### Properties
||Name||Description||
|DarkBrush|Brush for dark modules|
|LightBrush|Brush for light modules|
|QuietZoneModule|Number of modules for width of Quiet Zone|
|ErrorCorrectLevel|Error correction level for QrCode encode|
|Text|Input string for QrCode|
|IsFreezed|Boolean state if class is freezed|
|IsLocked|Boolean state if class is locked|

### Events
||Name||Description||
|DarkBrushChanged|Occurs when DarkBrush changes|
|LightBrushChanged|Occurs when LightBrush changes|
|QuietZoneModuleChanged|Occurs when QuietZoneModule changes|
|ErrorCorrectLevelChanged|Occurs when ErrorCorrectLevel changes|
|QrMatrixChanged|Occurs when re-encode, and BitMatrix changes|


### Example
{code:C#}
using Gma.QrCodeNet.Encoding.Windows.Forms;
using Gma.QrCodeNet.Encoding; //Import this only if you want to extract bitmatrix.
{code:C#}


{code:C#}
QrCodeImgControl qrControl = new QrCodeImgControl ();

//control update text then encode and recreate Image.
qrControl.Text = "QrCode.Net";

BitMatrix qrMatrix = qrControl.GetQrMatrix(); //Qr bit matrix for input string "QrCode.Net".

qrControl.Lock();  //Lock class.
qrControl.ErrorCorrectLevel = ErrorCorrectionLevel.M;  //It won't encode and recreate image.
qrControl.Text = "next test";
qrMatrix = qrControl.GetQrMatrix(); //Qr bit matrix for input string "QrCode.Net".
qrControl.QuietZoneModule = QuietZoneModules.Zero;  //Control will recreate image, but Bitmatrix is still for "QrCode.Net" input string. 
qrControl.Unlock(); //Unlock class, re-encode and repaint. 

qrMatrix = qrControl.GetQrMatrix(); //Qr bit matrix for input string "next test".

qrControl.Freeze() //Freeze class.
qrControl.DarkBrush = Brushes.Red; //It won't recreate image.
qrControl.Text = "freeze test"; //Control will re-encode, but won't recreate image right away. 
qrMatrix = qrControl.GetQrMatrix();  //QrCode matrix for string "Freeze test"
qrControl.UnFreeze(); //Recreate Image

qrControl.Lock();
qrControl.Freeze();
qrControl.LightBrush = Brushes.Yellow;  //It won't recreate image.
qrControl.Text = "Lock and Freeze test";  //Control won't re-encode.
qrMatrix = qrControl.GetQrMatrix();  //QrCode matrix is still for string "Freeze test"
qrControl.Unlock();    //Unlock class, re-encode QrCode but won't recreate image
qrControl.Unfreeze();  //UnFreeze class, recreate image.

//If lock and freeze together. Always Unlock before Unfreeze. Else it will recreate image twice. 

{code:C#}