# Background
Since we are dealing wit legacy code which was originally ported from C to Java and then to c# there are very few places we take over without any modification.
Below is the list of aspects we should keep in mind and take care of when rewriting.

# Coding Guidelines
Not beeng pity and paranoic about code style we recommend to stick to following guidelines: [http://csharpguidelines.codeplex.com/](http://csharpguidelines.codeplex.com/)

# Choice of Data Structures
Using the right Algorithms and Data Structures at right place will give you more significant performance gain than any bit tweaking.
[http://programmer.97things.oreilly.com/wiki/index.php/Use_the_Right_Algorithm_and_Data_Structure](http://programmer.97things.oreilly.com/wiki/index.php/Use_the_Right_Algorithm_and_Data_Structure)

# Using Existing Out-of-the-box Algorithms Where Possible
//TODO

# Avoiding Conditionals
//TODO

# Avoid Data Copying
//TODO

# Verbose Comments vs. Meaningful Names
Comment Only What the Code Cannot Say - is the name of an excellent short memo / article by Kevlin Henney. [http://programmer.97things.oreilly.com/wiki/index.php/Comment_Only_What_the_Code_Cannot_Say](http://programmer.97things.oreilly.com/wiki/index.php/Comment_Only_What_the_Code_Cannot_Say).
I would say in our project we should try to minimize comments by expressing intents by variable names and extracting short meaningful methods.
The legacy code we are rewriting is very often sprinkled with unnecessary comments telling you the "whole story" and cluttered with long methods each of them having 5 one-letter-name parameters.
Our goal is to make code not only work, but also readable. Try to do it in code and not in comments. On the other hand there things you can not express in code. Like chapter numbers and references to some constant tables or diagrams from specification. Such comment is a good comment.

... and one more thing at the end. Never write a comment to justify or explain your action, what do you do or why do you do. We have excellent source code control system and issue tracking which are interconnected. Put such a comment either in check-in or submit it as an issue.