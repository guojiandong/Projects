# ISizeCalculation
This page provides a guide to interface ISizeCalculation and its related classes. 

**Namespace**: Gma.QrCodeNet.Encoding.Windows.Render

### Remarks
ISizeCalculation is interface for different print size style. Classes that uses this interface are FixedCodeSize and FixedModuleSize. 

**FixedCodeSize**: This class is for people who want to draw QrCode at constant size. 
**FixedModuleSize**: This class is for people who want to draw QrCode at constant module size. (Check [QrCode info](QrCode) for information about module.)

### Constructors
||Name||Description||
|ISizeCalculation|Initialize a new instance of interface|
|FixedCodeSize|Initialize a new instance of FixedCodeSize class.|
|FixedModuleSize|Initialize a new instance of FixedModuleSize class.|

### Methods
||Name||Description||
|GetSize|Get DrawingSize struct for input matrix width|

### Example
{code:C#}
using Gma.QrCodeNet.Encoding.Windows.Render;
{code:C#}

{code:C#}
FixedCodeSize fCodeSize = new FixedCodeSize(200, QuietZoneModules.Two); //ISize, QrCode will be draw at 200 pixels x 200 pixels with quiet zone size at two. 
fCodeSize.QuietZoneModules = QuietZoneModules.Four;   //Change quiet zone size to four. 

DrawingSize dSize = fCodeSize.GetSize(21);    //21 is version 1 QrCode's width. GetSize method will be use by Renderer, it's not something people will be using during coding. 

FixedModuleSize fModuleSize = new FixedModuleSize(20, QuietZoneModules.Two);

//fModuleSize will cause Renderer to draw version 1 QrCode at width 462 pixels x 462 pixels. 
//Version 1 QrCode 21 modules for width.  21 * 20 + 2 * 20. 
{code:C#}